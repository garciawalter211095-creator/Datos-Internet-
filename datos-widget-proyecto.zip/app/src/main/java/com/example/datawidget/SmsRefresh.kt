package com.example.datawidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import java.time.LocalDate

/**
 * Lee la respuesta de Bait:
 * "Tu saldo al dia de hoy es de 12178 MB con vigencia al 14/11/2026 ..."
 */
class SmsRefresh : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val from = msgs.firstOrNull()?.originatingAddress ?: return
        if (!from.endsWith(RefreshActivity.BAIT_NUMBER)) return
        val body = msgs.joinToString("") { it.messageBody ?: "" }

        val mb = Regex("""([\d.,]+)\s*MB""", RegexOption.IGNORE_CASE).find(body)
            ?.groupValues?.get(1)?.filter { it.isDigit() }?.toFloatOrNull() ?: return
        val date = Regex("""(\d{1,2})/(\d{1,2})/(\d{4})""").find(body)?.groupValues

        val prefs = ctx.getSharedPreferences("plan", Context.MODE_PRIVATE)
        val e = prefs.edit()
        val gb = mb / 1024f
        e.putFloat("bait_left", gb)
        if (prefs.getFloat("bait_total", 0f) < gb) e.putFloat("bait_total", gb)
        if (date != null) {
            runCatching {
                LocalDate.of(date[3].toInt(), date[2].toInt(), date[1].toInt()).toEpochDay()
            }.onSuccess { e.putLong("bait_cutEpoch", it) }
        }
        e.apply()
        DataWidget.updateAll(ctx)
    }
}
