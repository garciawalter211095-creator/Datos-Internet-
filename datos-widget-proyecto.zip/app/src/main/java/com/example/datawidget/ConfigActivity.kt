package com.example.datawidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class ConfigActivity : Activity() {

    private val num = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL

    private fun field(hint: String, value: String, type: Int) = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = type
    }

    private fun fmt(f: Float) = String.format(Locale.US, "%.1f", f)

    /** Un bloque de campos por compañía ("bait" o "telcel"). */
    private inner class Section(val c: String, title: String, val p: SharedPreferences) {
        val head = TextView(this@ConfigActivity).apply {
            text = title
            textSize = 18f
            setPadding(0, 32, 0, 0)
        }
        val left = field("GB libres (se llena solo al tocar ↻)",
            if (p.contains("${c}_left")) fmt(p.getFloat("${c}_left", 0f)) else "", num)
        val total = field("GB totales del plan (opcional)",
            p.getFloat("${c}_total", 0f).let { if (it > 0) fmt(it) else "" }, num)
        val cut = field("Día de corte 1-31 (vacío = automático)",
            p.getInt("${c}_cutDay", 0).let { if (it > 0) it.toString() else "" },
            InputType.TYPE_CLASS_NUMBER)
        val social = field("Redes ilimitadas (ej: WhatsApp, Facebook)",
            p.getString("${c}_social", "") ?: "", InputType.TYPE_CLASS_TEXT)

        val views get() = listOf(head, left, total, cut, social)

        fun save(e: SharedPreferences.Editor) {
            left.text.toString().toFloatOrNull()?.let { e.putFloat("${c}_left", it) }
            e.putFloat("${c}_total", total.text.toString().toFloatOrNull() ?: 0f)
            val d = cut.text.toString().toIntOrNull()
            if (d != null) {
                e.putInt("${c}_cutDay", d.coerceIn(1, 31))
                e.remove("${c}_cutEpoch")
            }
            e.putString("${c}_social", social.text.toString())
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED)

        val perms = arrayOf(android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS)
        if (perms.any { checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED })
            requestPermissions(perms, 1)

        val p = getSharedPreferences("plan", Context.MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val bait = Section("bait", "Bait", p)
        val telcel = Section("telcel", "Telcel", p)

        val save = Button(this).apply { text = "Guardar" }
        val acc = Button(this).apply {
            text = "Activar lector de Mi Telcel (Accesibilidad)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        save.setOnClickListener {
            val e = p.edit()
            bait.save(e)
            telcel.save(e)
            e.apply()
            DataWidget.updateAll(this)
            if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
            }
            finish()
        }

        setContentView(ScrollView(this).apply {
            addView(LinearLayout(this@ConfigActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(pad, pad, pad, pad)
                (bait.views + telcel.views + listOf(save, acc)).forEach { addView(it) }
            })
        })
    }
}
