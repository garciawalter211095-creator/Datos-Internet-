package com.example.datawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

class DataWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    private class Ids(val gb: Int, val bar: Int, val cut: Int, val social: Int, val refresh: Int)

    companion object {
        private val BAIT = Ids(R.id.b_gb, R.id.b_bar, R.id.b_cut, R.id.b_social, R.id.b_refresh)
        private val TELCEL = Ids(R.id.t_gb, R.id.t_bar, R.id.t_cut, R.id.t_social, R.id.t_refresh)

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            mgr.getAppWidgetIds(ComponentName(ctx, DataWidget::class.java))
                .forEach { update(ctx, mgr, it) }
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            bind(ctx, v, "bait", BAIT, 1)
            bind(ctx, v, "telcel", TELCEL, 2)
            v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(
                ctx, 0, Intent(ctx, ConfigActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            mgr.updateAppWidget(id, v)
        }

        private fun bind(ctx: Context, v: RemoteViews, c: String, ids: Ids, req: Int) {
            val p = ctx.getSharedPreferences("plan", Context.MODE_PRIVATE)
            val has = p.contains("${c}_left")
            val left = p.getFloat("${c}_left", 0f)
            val total = p.getFloat("${c}_total", 0f)
            val epoch = p.getLong("${c}_cutEpoch", -1L)
            val cutDay = p.getInt("${c}_cutDay", 0)
            val social = p.getString("${c}_social", "") ?: ""

            v.setTextViewText(ids.gb, when {
                !has -> "Sin datos"
                total > 0 -> "${fmt1(left)} / ${fmt1(total)}"
                else -> "${fmt1(left)} GB"
            })
            val pct = when {
                !has -> 0
                total > 0 -> ((left / total) * 100).toInt().coerceIn(0, 100)
                else -> 100
            }
            v.setProgressBar(ids.bar, 100, pct, false)

            val cut: LocalDate? = when {
                epoch >= 0 -> LocalDate.ofEpochDay(epoch)
                cutDay in 1..31 -> nextCut(cutDay)
                else -> null
            }
            val label = if (c == "bait") "Vigencia" else "Corte"
            val fmt = DateTimeFormatter.ofPattern("d MMM", Locale("es"))
            v.setTextViewText(ids.cut, if (cut == null) "" else {
                val days = ChronoUnit.DAYS.between(LocalDate.now(), cut)
                "$label ${cut.format(fmt)} · " + when {
                    days < 0 -> "vencida"
                    days == 0L -> "hoy"
                    else -> "${days} d"
                }
            })
            v.setTextViewText(ids.social, if (social.isBlank()) "" else "∞ $social")

            val intent = Intent(ctx, RefreshActivity::class.java)
                .putExtra("c", c)
                .setData(Uri.parse("datoswidget://refresh/$c"))
            v.setOnClickPendingIntent(ids.refresh, PendingIntent.getActivity(
                ctx, req, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        }

        private fun fmt1(f: Float) = String.format(Locale.US, "%.1f", f)

        private fun nextCut(day: Int): LocalDate {
            val today = LocalDate.now()
            fun inMonth(d: LocalDate) = d.withDayOfMonth(minOf(day, d.lengthOfMonth()))
            val thisMonth = inMonth(today)
            return if (!thisMonth.isBefore(today)) thisMonth else inMonth(today.plusMonths(1))
        }
    }
}
