package com.example.datawidget

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.time.LocalDate
import java.util.Locale

/**
 * Lee la pantalla de inicio de Mi Telcel:
 *  - pestaña "Datos de mi plan"  -> "Te quedan X GB"
 *  - pestaña "Datos Promocionales" -> "Te quedan Y GB"
 *  - "Faltan N días para el próximo corte"
 * Suma X + Y y lo guarda para el widget.
 */
class MiTelcelReader : AccessibilityService() {

    companion object {
        @Volatile var instance: MiTelcelReader? = null
        @Volatile var targetPkg: String? = null
        private const val TIMEOUT_MS = 25_000L
    }

    private val h = Handler(Looper.getMainLooper())
    private var running = false

    override fun onServiceConnected() { instance = this }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Se llama justo después de abrir Mi Telcel. */
    fun start() {
        if (running) return
        running = true
        val t0 = System.currentTimeMillis()
        h.postDelayed({ waitForHome(t0) }, 2500)
    }

    private fun appRoot(): AccessibilityNodeInfo? {
        val r = rootInActiveWindow ?: return null
        return if (r.packageName?.toString() == targetPkg) r else null
    }

    private fun waitForHome(t0: Long) {
        val root = appRoot()
        if (root != null && collect(root).any { it.equals("Mi consumo actual", true) }) {
            readAll()
            return
        }
        if (System.currentTimeMillis() - t0 > TIMEOUT_MS) {
            finishWith("No pude abrir la pantalla de consumo en Mi Telcel")
            return
        }
        root?.let { clickText(it, "Inicio") }
        h.postDelayed({ waitForHome(t0) }, 1000)
    }

    private fun readAll() {
        appRoot()?.let { clickText(it, "Datos de mi plan") }
        h.postDelayed({
            val plan = readRemainingGb()
            val days = readDays()
            val clicked = appRoot()?.let { clickText(it, "Datos Promocionales") } ?: false
            h.postDelayed({
                val promo = if (clicked) readRemainingGb() else null
                if (plan == null && promo == null) {
                    finishWith("No encontré tus datos en Mi Telcel")
                } else {
                    save((plan ?: 0f) + (promo ?: 0f), days)
                }
            }, 1800)
        }, 1800)
    }

    private fun readRemainingGb(): Float? {
        val texts = collect(appRoot() ?: return null)
        val rx = Regex("""(\d[\d.,]*)\s*(GB|MB)""", RegexOption.IGNORE_CASE)
        var sum = 0f
        var found = false
        texts.forEachIndexed { i, t ->
            if (t.contains("te quedan", ignoreCase = true)) {
                val cand = (listOf(t.lowercase().substringAfter("quedan", "")) +
                    texts.drop(i + 1).take(3)).joinToString(" ")
                val m = rx.find(cand) ?: return@forEachIndexed
                val n = m.groupValues[1].replace(",", "").toFloatOrNull() ?: return@forEachIndexed
                sum += if (m.groupValues[2].equals("GB", true)) n else n / 1024f
                found = true
            }
        }
        return if (found) sum else null
    }

    private fun readDays(): Int? {
        val all = collect(appRoot() ?: return null).joinToString(" ")
        return Regex("""Faltan\s+(\d+)\s*d[ií]as?""", RegexOption.IGNORE_CASE)
            .find(all)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun save(gb: Float, days: Int?) {
        val e = getSharedPreferences("plan", Context.MODE_PRIVATE).edit()
            .putFloat("telcel_left", gb)
            .putFloat("telcel_total", 0f)
        if (days != null) {
            e.putLong("telcel_cutEpoch", LocalDate.now().plusDays(days.toLong()).toEpochDay())
        }
        e.apply()
        DataWidget.updateAll(this)
        finishWith(String.format(Locale.US, "Telcel: te quedan %.1f GB", gb))
    }

    private fun finishWith(msg: String) {
        running = false
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    // ---------- utilidades ----------
    private fun collect(root: AccessibilityNodeInfo?): List<String> {
        val out = ArrayList<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = (n.text ?: n.contentDescription)?.toString()
            if (!t.isNullOrBlank()) out.add(t.trim())
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    private fun clickText(root: AccessibilityNodeInfo, label: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(label) ?: return false
        for (n in nodes) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim() ?: continue
            if (!t.equals(label, ignoreCase = true)) continue
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }
}
