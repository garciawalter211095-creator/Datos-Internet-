package com.example.datawidget

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.SmsManager
import android.widget.Toast

/** Se abre al tocar ↻ en el widget, hace su trabajo y se cierra al instante. */
class RefreshActivity : Activity() {

    companion object {
        const val BAIT_NUMBER = "52142"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent?.getStringExtra("c")) {
            "telcel" -> refreshTelcel()
            "bait" -> refreshBait()
        }
        finish()
    }

    private fun refreshBait() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Abre la app y da permiso de SMS", Toast.LENGTH_LONG).show()
            return
        }
        val sms: SmsManager? = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(SmsManager::class.java)
        } else {
            legacySms()
        }
        sms?.sendTextMessage(BAIT_NUMBER, null, "SALDO", null, null)
        Toast.makeText(this, "Consultando saldo Bait…", Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun legacySms(): SmsManager? = SmsManager.getDefault()

    private fun refreshTelcel() {
        val reader = MiTelcelReader.instance
        if (reader == null) {
            Toast.makeText(this, "Activa «Datos Widget» en Accesibilidad", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val launch = findMiTelcel()
        if (launch == null) {
            Toast.makeText(this, "No encontré la app Mi Telcel", Toast.LENGTH_LONG).show()
            return
        }
        MiTelcelReader.targetPkg = launch.component?.packageName ?: launch.`package`
        startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Toast.makeText(this, "Leyendo Mi Telcel…", Toast.LENGTH_SHORT).show()
        reader.start()
    }

    private fun findMiTelcel(): Intent? {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ri = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().contains("telcel", ignoreCase = true)
        } ?: return null
        return pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
    }
}
